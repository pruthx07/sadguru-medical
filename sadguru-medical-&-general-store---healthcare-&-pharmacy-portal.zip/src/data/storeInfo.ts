/**
 * ==============================================================================
 * SADGURU MEDICAL - OFFICIAL STORE CREDENTIALS & LOCATION DATA
 * ==============================================================================
 *
 * [STUDENT PROJECT VIVA NOTE]:
 * This file maintains the single source of truth for your brother's pharmacy
 * in Kasba Tarle, Radhanagri. Storing configuration in dedicated data files
 * makes your application modular, clean, and easy to maintain.
 */

import { StoreInfo } from '../types/pharmacy';

export const SADGURU_STORE_INFO: StoreInfo = {
  name: 'Sadguru Medical & General Store',
  marathiName: 'सद्गुरु मेडिकल अँड जनरल स्टोअर',
  tagline: 'Your Trusted 24x7 Community Healthcare & Pharmacy Partner',
  ownerName: 'Gurudas Teli',
  address: {
    village: 'Kasba Tarle',
    taluka: 'Radhanagri',
    district: 'Kolhapur',
    state: 'Maharashtra',
    pincode: '416211',
    landmark: 'Main Road, Near Tarle Bus Stand & Grampanchayat'
  },
  phones: ['+91 94054 17142', '+91 94054 17142'],
  whatsapp: '919405417142', // For direct WhatsApp ordering links
  email: 'sadgurumedical.tarle@gmail.com',
  licenseNumber: 'FDA MH-KOL-284910 / 20B & 21B',
  gstin: '27AABCS9876Q1Z2',
  pharmacistOnDuty: 'Gurudas Teli (Reg. Pharmacist, MSPC Reg. No. 184592)',
  degrees: 'Registered Pharmacist - Maharashtra State Pharmacy Council',
  hours: 'Open 7:00 AM – 11:00 PM Daily (24x7 Emergency On-Call available)',
  emergency24x7: true
};

// Villages covered for direct bike / van delivery from Kasba Tarle store
export const DELIVERY_AREAS = [
  { name: 'Kasba Tarle', pincode: '416211', deliveryTime: '30 - 45 Mins', freeAbove: 200 },
  { name: 'Radhanagri Town', pincode: '416212', deliveryTime: '1 - 2 Hours', freeAbove: 350 },
  { name: 'Walur', pincode: '416211', deliveryTime: '45 - 60 Mins', freeAbove: 250 },
  { name: 'Solankur', pincode: '416212', deliveryTime: '1 - 2 Hours', freeAbove: 400 },
  { name: 'Fejivade', pincode: '416212', deliveryTime: '1.5 - 2 Hours', freeAbove: 400 },
  { name: 'Shiroli Dhangerwadi', pincode: '416211', deliveryTime: '45 - 60 Mins', freeAbove: 250 },
  { name: 'Kagal / Kolhapur Outskirts', pincode: '416001', deliveryTime: 'Same Day Express', freeAbove: 500 },
];
