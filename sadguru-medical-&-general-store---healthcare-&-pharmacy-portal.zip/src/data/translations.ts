/**
 * ==============================================================================
 * BILINGUAL LOCALIZATION (ENGLISH & MARATHI)
 * ==============================================================================
 *
 * [STUDENT PROJECT NOTE]:
 * In Maharashtra rural healthcare, accessibility in the regional language (Marathi)
 * is critical for senior citizens and local villagers in Kasba Tarle & Radhanagri.
 * This file provides key-value localization dictionaries.
 */

export type Language = 'en' | 'mr';

export const TRANSLATIONS = {
  en: {
    storeName: 'Sadguru Medical & General Store',
    tagline: 'Reliable 24x7 Medicines & Healthcare at Kasba Tarle, Kolhapur',
    navCatalog: 'Medicines',
    navUploadRx: 'Upload Prescription',
    navGenericSaver: 'Generic Price Saver',
    navDoseTracker: 'Pill Reminder',
    navStoreInfo: 'Store & Contact',
    searchPlaceholder: 'Search medicines by brand name (e.g., Dolo, Pantocid) or active salt...',
    rxRequiredBadge: 'Prescription Required',
    otcBadge: 'No Rx Needed',
    genericSavings: 'Save with Generic',
    addToCart: 'Add to Cart',
    outOfStock: 'Out of Stock',
    emergencyBanner: '24x7 Emergency Medicine Delivery in Kasba Tarle & Radhanagri',
    orderViaWhatsApp: 'Order on WhatsApp',
    quickUploadTitle: 'Quick Prescription Upload',
    quickUploadSubtitle: 'Take a photo of your doctor\'s prescription. Our certified pharmacist will verify and pack your order.',
    cartTitle: 'Your Healthcare Basket',
    checkout: 'Proceed to Checkout',
    emptyCart: 'Your basket is currently empty',
    totalAmount: 'Total Payable Amount',
    cashOnDelivery: 'Cash on Delivery (COD)',
    upiPayment: 'Instant UPI / QR Code',
    storePickup: 'Pickup at Tarle Store',
    verifyGenericNotice: 'Save up to 80% with medically bio-equivalent Jan Aushadhi generic salts',
  },
  mr: {
    storeName: 'सद्गुरु मेडिकल अँड जनरल स्टोअर',
    tagline: 'कसबा तारळे, राधानगरी व कोल्हापूर परिसरासाठी २४ तास हक्काची फार्मसी',
    navCatalog: 'औषधे',
    navUploadRx: 'प्रिस्क्रिप्शन अपलोड',
    navGenericSaver: 'जेनेरिक बचत कॅल्क्युलेटर',
    navDoseTracker: 'डोस स्मरणपत्र (रिमाइंडर)',
    navStoreInfo: 'पत्ता व संपर्क',
    searchPlaceholder: 'औषधाचे नाव किंवा घटक शोधा (उदा. डोलो, पॅरासिटामॉल, पॅन्टॉसिड)...',
    rxRequiredBadge: 'डॉक्टरांची चिठ्ठी आवश्यक',
    otcBadge: 'थेट उपलब्ध',
    genericSavings: 'जेनेरिकमध्ये बचत करा',
    addToCart: 'कार्टमध्ये जोडा',
    outOfStock: 'स्टॉकमध्ये नाही',
    emergencyBanner: 'कसबा तारळे आणि राधानगरी तालुक्यात २४ तास इमर्जन्सी औषध सेवा',
    orderViaWhatsApp: 'व्हॉट्सअॅपवर ऑर्डर करा',
    quickUploadTitle: 'डॉक्टरांची चिठ्ठी (प्रिस्क्रिप्शन) अपलोड करा',
    quickUploadSubtitle: 'तुमच्या प्रिस्क्रिप्शनचा फोटो काढा किंवा फाईल अपलोड करा. आमचे फार्मासिस्ट औषधे तपासून घरपोच पाठवतील.',
    cartTitle: 'तुमची औषध बास्केट',
    checkout: 'ऑर्डर पूर्ण करा',
    emptyCart: 'तुमची बास्केट सध्या रिकामी आहे',
    totalAmount: 'एकूण देय रक्कम',
    cashOnDelivery: 'कॅश ऑन डिलिव्हरी (COD)',
    upiPayment: 'गुगल पे / फोन पे (UPI)',
    storePickup: 'तारळे मेडिकल दुकानातून स्वतः घ्या',
    verifyGenericNotice: 'समान घटक असलेल्या जेनेरिक औषधांवर ८०% पर्यंत थेट बचत मिळवा',
  }
};
