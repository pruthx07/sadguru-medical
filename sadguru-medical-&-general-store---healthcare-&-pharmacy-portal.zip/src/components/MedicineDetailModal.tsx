/**
 * ==============================================================================
 * MEDICINE CLINICAL DETAIL MODAL (PDP - Product Detail View)
 * ==============================================================================
 *
 * [STUDENT PROJECT EXPLANATION]:
 * This modal acts as the comprehensive clinical monograph for any medicine.
 * Following healthcare transparency standards:
 * - Displays active salt composition and manufacturer
 * - Clear dosage instructions and food intake rules
 * - Safety advice for pregnancy, alcohol, and driving
 * - Quantity selector and direct Add to Cart handler
 */

import React, { useState } from 'react';
import { 
  X, 
  Pill, 
  ShieldAlert, 
  Clock, 
  Building2, 
  CheckCircle2, 
  Plus, 
  Minus, 
  ShoppingBag,
  Sparkles,
  AlertTriangle
} from 'lucide-react';
import { Medicine } from '../types/pharmacy';
import { Language } from '../data/translations';

interface MedicineDetailModalProps {
  medicine: Medicine | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCartWithQty: (med: Medicine, quantity: number) => void;
  onOpenGenericSaver: (med: Medicine) => void;
  language: Language;
}

export const MedicineDetailModal: React.FC<MedicineDetailModalProps> = ({
  medicine,
  isOpen,
  onClose,
  onAddToCartWithQty,
  onOpenGenericSaver,
  language,
}) => {
  const [quantity, setQuantity] = useState(1);

  if (!isOpen || !medicine) return null;

  const handleIncrement = () => setQuantity(q => q + 1);
  const handleDecrement = () => setQuantity(q => (q > 1 ? q - 1 : 1));

  const handleAddToCart = () => {
    onAddToCartWithQty(medicine, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 relative my-8 text-left max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          aria-label="Close Medicine Details"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Header & Classification */}
        <div className="flex items-start gap-4 mb-5">
          <div className="w-14 h-14 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 border border-emerald-100">
            <Pill className="w-7 h-7" />
          </div>

          <div className="flex-1 pr-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-0.5">
              <span>{medicine.brand}</span>
              <span aria-hidden="true">·</span>
              <span>{medicine.dosageForm}</span>
              <span aria-hidden="true">·</span>
              <span className={medicine.prescriptionRequired ? 'text-red-600 font-mono' : 'text-emerald-700'}>
                {medicine.prescriptionRequired ? 'Rx Prescription' : 'OTC Self Care'}
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-display">
              {language === 'mr' ? medicine.marathiName : medicine.name}
            </h2>

            <div className="text-xs text-slate-500 font-mono mt-0.5">
              Active Salt: <strong className="text-slate-700">{medicine.composition}</strong>
            </div>
          </div>
        </div>

        {/* Pricing, Stock & Contiguous Purchase Strip */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="text-[11px] text-slate-500 font-medium">Selling Price per {medicine.packSize}:</div>
            <div className="flex items-baseline gap-2 font-mono tabular-nums">
              <span className="text-2xl font-black text-slate-900">
                ₹{(medicine.sellingPrice * quantity).toFixed(2)}
              </span>
              {medicine.mrp > medicine.sellingPrice && (
                <span className="text-xs text-slate-400 line-through">
                  ₹{(medicine.mrp * quantity).toFixed(2)}
                </span>
              )}
              {medicine.discountPercent > 0 && (
                <span className="text-xs text-emerald-700 font-semibold">
                  ({medicine.discountPercent}% OFF)
                </span>
              )}
            </div>
            <div className="text-[11px] text-emerald-800 font-medium flex items-center gap-1 mt-0.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>In Stock at Kasba Tarle store ({medicine.stockCount} available)</span>
            </div>
          </div>

          {/* Quantity Stepper & Add to Cart */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="flex items-center border border-slate-300 rounded-lg bg-white overflow-hidden">
              <button
                onClick={handleDecrement}
                className="px-2.5 py-1.5 text-slate-600 hover:bg-slate-100 transition-colors"
                aria-label="Decrease quantity"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="px-3 py-1 text-xs font-bold font-mono text-slate-800">
                {quantity}
              </span>
              <button
                onClick={handleIncrement}
                className="px-2.5 py-1.5 text-slate-600 hover:bg-slate-100 transition-colors"
                aria-label="Increase quantity"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <button
              onClick={handleAddToCart}
              className="flex-1 sm:flex-none px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{language === 'en' ? 'Add to Basket' : 'बास्केटमध्ये टाका'}</span>
            </button>
          </div>
        </div>

        {/* Generic Alternate Callout (if available) */}
        {medicine.genericEquivalent && (
          <div className="mb-6 p-3.5 bg-blue-50/80 border border-blue-200 rounded-xl flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-blue-600 shrink-0" />
              <div>
                <div className="text-xs font-bold text-blue-900">
                  Save {medicine.genericEquivalent.savingsPercent}% with Jan Aushadhi Generic Salt
                </div>
                <div className="text-[11px] text-blue-700">
                  {medicine.genericEquivalent.saltName} @ ₹{medicine.genericEquivalent.genericPrice.toFixed(2)}
                </div>
              </div>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenGenericSaver(medicine);
              }}
              className="text-xs font-semibold px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shrink-0"
            >
              Compare
            </button>
          </div>
        )}

        {/* Clinical Information Sections */}
        <div className="space-y-4 text-xs text-slate-700">
          
          {/* Section: Overview & Uses */}
          <div>
            <h4 className="font-bold text-slate-900 mb-1.5 uppercase tracking-wider text-[11px]">
              Key Clinical Uses & Benefits:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {medicine.uses.map((use, idx) => (
                <div key={idx} className="flex items-center gap-2 text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{use}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: How to Use */}
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div className="flex items-center gap-1.5 font-bold text-slate-900 mb-1">
              <Clock className="w-3.5 h-3.5 text-emerald-700" />
              <span>How & When to Consume:</span>
            </div>
            <p className="text-slate-600 leading-relaxed">
              {medicine.howToUse}
            </p>
          </div>

          {/* Section: Safety Advice (Pregnancy, Alcohol, Driving) */}
          <div>
            <h4 className="font-bold text-slate-900 mb-2 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
              <span>Safety & Precautions:</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="p-2.5 rounded-lg bg-amber-50/60 border border-amber-200/80">
                <span className="font-bold text-amber-900 block mb-0.5">Alcohol:</span>
                <span className="text-slate-600 text-[11px]">{medicine.safetyAdvice.alcohol}</span>
              </div>
              <div className="p-2.5 rounded-lg bg-amber-50/60 border border-amber-200/80">
                <span className="font-bold text-amber-900 block mb-0.5">Pregnancy:</span>
                <span className="text-slate-600 text-[11px]">{medicine.safetyAdvice.pregnancy}</span>
              </div>
              <div className="p-2.5 rounded-lg bg-amber-50/60 border border-amber-200/80">
                <span className="font-bold text-amber-900 block mb-0.5">Driving:</span>
                <span className="text-slate-600 text-[11px]">{medicine.safetyAdvice.driving}</span>
              </div>
            </div>
          </div>

          {/* Manufacturer & Store Dispensing Notice */}
          <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-100 flex items-center justify-between">
            <span>Manufactured by: {medicine.manufacturer}</span>
            <span>Dispensed by: Sadguru Medical, Kasba Tarle</span>
          </div>

        </div>

      </div>
    </div>
  );
};
