/**
 * ==============================================================================
 * PRODUCT CARD COMPONENT (Clean Clinical Metadata & Zero-Pill Design)
 * ==============================================================================
 *
 * [STUDENT PROJECT EXPLANATION]:
 * This component represents an individual medicine item.
 * It strictly implements the frontend design constitution:
 * - Clean unboxed metadata separated by '·'
 * - Tabular numerals (tabular-nums) for prices in INR (₹)
 * - Clinical fallback graphics so cards look gorgeous even without external URLs
 * - Direct Add to Cart and Quick Generic Alternate comparison triggers
 */

import React from 'react';
import { Plus, Check, Sparkles, AlertCircle, Pill } from 'lucide-react';
import { Medicine } from '../types/pharmacy';
import { Language } from '../data/translations';

interface MedicineCardProps {
  medicine: Medicine;
  language: Language;
  onAddToCart: (med: Medicine) => void;
  onSelectMedicine: (med: Medicine) => void;
  onCompareGeneric: (med: Medicine) => void;
  isItemInCart: boolean;
}

export const MedicineCard: React.FC<MedicineCardProps> = ({
  medicine,
  language,
  onAddToCart,
  onSelectMedicine,
  onCompareGeneric,
  isItemInCart,
}) => {
  return (
    <div className="group flex flex-col bg-white rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-md transition-all overflow-hidden text-left">
      
      {/* Product Visual Container (Fallback-Resilient Clinical Canvas) */}
      <div 
        onClick={() => onSelectMedicine(medicine)}
        className={`relative h-44 w-full cursor-pointer flex flex-col items-center justify-center p-4 transition-colors ${
          medicine.imageBgColor || 'bg-slate-50'
        }`}
      >
        {/* Subtle Regulatory Tag (Clean unboxed text) */}
        <div className="absolute top-2.5 left-3 flex items-center gap-1.5 text-[11px] font-semibold text-slate-600">
          {medicine.prescriptionRequired ? (
            <span className="text-red-700 flex items-center gap-1 font-mono">
              <AlertCircle className="w-3 h-3" />
              <span>Rx Required</span>
            </span>
          ) : (
            <span className="text-emerald-700">OTC Daily Care</span>
          )}
        </div>

        {/* Generic Savings Flag (Subtle unboxed flag, NOT rounded candy pill) */}
        {medicine.genericEquivalent && (
          <div className="absolute top-2.5 right-3 text-[11px] font-bold text-blue-700">
            Save {medicine.genericEquivalent.savingsPercent}%
          </div>
        )}

        {/* Central Medicine Graphic Icon */}
        <div className="w-16 h-16 rounded-2xl bg-white shadow-xs flex items-center justify-center text-slate-700 group-hover:scale-105 transition-transform">
          <Pill className="w-8 h-8 text-emerald-600" />
        </div>

        {/* Pack Size / Dosage Form footer */}
        <div className="mt-3 text-[11px] text-slate-500 font-medium">
          {medicine.dosageForm} · {medicine.packSize}
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Unboxed Brand & Manufacturer Metadata */}
          <div className="text-[11px] text-slate-500 font-medium flex items-center gap-1.5 mb-1">
            <span className="font-semibold text-slate-700">{medicine.brand}</span>
            <span aria-hidden="true">·</span>
            <span className="truncate max-w-[150px]">{medicine.manufacturer}</span>
          </div>

          {/* Product Name (Clickable) */}
          <h3 
            onClick={() => onSelectMedicine(medicine)}
            className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors cursor-pointer line-clamp-1"
          >
            {language === 'mr' ? medicine.marathiName : medicine.name}
          </h3>

          {/* Active Chemical Composition */}
          <p className="text-xs text-slate-500 font-mono mt-1 line-clamp-1">
            {medicine.composition}
          </p>

          {/* Generic Substitute Trigger Link */}
          {medicine.genericEquivalent && (
            <button
              onClick={() => onCompareGeneric(medicine)}
              className="mt-2 text-[11px] font-semibold text-blue-700 hover:text-blue-900 flex items-center gap-1 transition-colors"
            >
              <Sparkles className="w-3 h-3" />
              <span>
                {language === 'en'
                  ? `Generic salt: ₹${medicine.genericEquivalent.genericPrice.toFixed(2)}`
                  : `जेनेरिक किंमत: ₹${medicine.genericEquivalent.genericPrice.toFixed(2)}`}
              </span>
            </button>
          )}
        </div>

        {/* Pricing & Add to Cart Action Row */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1.5 font-mono tabular-nums">
              <span className="text-lg font-bold text-slate-900">
                ₹{medicine.sellingPrice.toFixed(2)}
              </span>
              {medicine.mrp > medicine.sellingPrice && (
                <span className="text-xs text-slate-400 line-through">
                  ₹{medicine.mrp.toFixed(2)}
                </span>
              )}
            </div>
            {medicine.discountPercent > 0 && (
              <span className="text-[10px] text-emerald-700 font-medium">
                {medicine.discountPercent}% off MRP
              </span>
            )}
          </div>

          {/* Add to Cart Button */}
          <button
            onClick={() => onAddToCart(medicine)}
            disabled={!medicine.inStock}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 ${
              !medicine.inStock
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                : isItemInCart
                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs'
            }`}
          >
            {isItemInCart ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>{language === 'en' ? 'Add' : 'जोडा'}</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
