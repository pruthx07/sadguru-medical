/**
 * ==============================================================================
 * PRESCRIPTION UPLOAD & ORDER VERIFICATION MODAL
 * ==============================================================================
 *
 * [STUDENT PROJECT VIVA EXPLANATION]:
 * In clinical e-pharmacies, Schedule H and Schedule X prescription medicines
 * cannot be dispensed without a valid registered medical practitioner's (RMP)
 * prescription.
 *
 * This component provides:
 * 1. Image upload with client-side FileReader preview.
 * 2. Patient demographics capture (Name, Age, Village/Taluka, Phone).
 * 3. Pharmacist verification workflow & WhatsApp direct dispatch.
 */

import React, { useState } from 'react';
import { X, Upload, CheckCircle2, ShieldCheck, AlertCircle, FileText, Send, PhoneCall } from 'lucide-react';
import { Language } from '../data/translations';
import { SADGURU_STORE_INFO } from '../data/storeInfo';

interface PrescriptionUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const PrescriptionUploadModal: React.FC<PrescriptionUploadModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  // Local component states
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [village, setVillage] = useState('Kasba Tarle');
  const [doctorName, setDoctorName] = useState('');
  const [notes, setNotes] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [orderRef, setOrderRef] = useState('');

  if (!isOpen) return null;

  // Handle image upload from file input
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Set a pre-loaded sample prescription for quick testing/demo during college project review!
  const loadDemoPrescription = () => {
    // A clean SVG data URI representing a Doctor's Prescription
    const svgSample = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="280" viewBox="0 0 400 280" fill="%23f8fafc"><rect width="400" height="280" fill="%23ffffff" stroke="%23cbd5e1" stroke-width="2"/><text x="20" y="35" font-family="sans-serif" font-size="16" font-weight="bold" fill="%230f172a">Dr. A. R. Patil, M.B.B.S., M.D.</text><text x="20" y="55" font-family="sans-serif" font-size="12" fill="%2364748b">Reg. No: MMC-2015-084 · Kolhapur Clinic</text><line x1="20" y1="70" x2="380" y2="70" stroke="%23e2e8f0" stroke-width="1.5"/><text x="20" y="95" font-family="serif" font-size="22" font-weight="bold" fill="%23047857">Rx</text><text x="60" y="100" font-family="sans-serif" font-size="14" font-weight="600" fill="%231e293b">1. Tab. Pantocid 40mg (1-0-0 Before Food) x 7 days</text><text x="60" y="130" font-family="sans-serif" font-size="14" font-weight="600" fill="%231e293b">2. Tab. Dolo 650mg (1-0-1 After Food SOS) x 3 days</text><text x="60" y="160" font-family="sans-serif" font-size="14" font-weight="600" fill="%231e293b">3. Tab. Augmentin 625 Duo (1-0-1 with meal) x 5 days</text><line x1="20" y1="210" x2="380" y2="210" stroke="%23e2e8f0" stroke-width="1"/><text x="20" y="240" font-family="sans-serif" font-size="12" fill="%23059669">Patient: Verified Adult · Kasba Tarle</text><text x="300" y="250" font-family="serif" font-style="italic" font-size="14" fill="%2364748b">Patil Dr. Sign</text></svg>`;
    setPreviewImage(svgSample);
    setPatientName('Anil Patil');
    setPatientAge('42');
    setPatientPhone('9822156789');
    setDoctorName('Dr. A. R. Patil, M.D.');
    setNotes('Please send generic substitutes if available for cost savings.');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName || !patientPhone) return;

    // Generate simulated order reference ID (e.g. RX-TARLE-4821)
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const generatedId = `RX-TARLE-${randomNum}`;
    setOrderRef(generatedId);
    setIsSubmitted(true);
  };

  const handleSendToWhatsApp = () => {
    const message = encodeURIComponent(
      `*New Prescription Order - Sadguru Medical Kasba Tarle*\n\n` +
      `*Patient Name:* ${patientName}\n` +
      `*Age:* ${patientAge}\n` +
      `*Phone:* ${patientPhone}\n` +
      `*Location:* ${village}, Tal. Radhanagri, Dist. Kolhapur\n` +
      `*Doctor:* ${doctorName || 'Not specified'}\n` +
      `*Notes:* ${notes || 'Standard fulfillment'}\n\n` +
      `Please review the prescription slip and confirm delivery.`
    );
    window.open(`https://wa.me/${SADGURU_STORE_INFO.whatsapp}?text=${message}`, '_blank');
  };

  const resetForm = () => {
    setIsSubmitted(false);
    setPatientName('');
    setPatientAge('');
    setPatientPhone('');
    setDoctorName('');
    setNotes('');
    setPreviewImage(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 relative my-8 text-left">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          aria-label="Close Prescription Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <div>
            {/* Modal Title & Regulatory Subtext */}
            <div className="mb-6">
              <div className="flex items-center gap-2 text-emerald-800 text-xs font-semibold uppercase tracking-wider mb-1">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>Maharashtra FDA Compliant Prescription Desk</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 font-display">
                {language === 'en' ? 'Upload Doctor\'s Prescription' : 'डॉक्टरांची चिठ्ठी (प्रिस्क्रिप्शन) अपलोड करा'}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                {language === 'en'
                  ? 'Our registered pharmacist at Kasba Tarle will review your prescription, verify dosages, and pack your medicines securely.'
                  : 'आमचे कसबा तारळे येथील नोंदणीकृत फार्मासिस्ट तुमची चिठ्ठी तपासून खात्रीशीर औषधे घरपोच पाठवतील.'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Prescription Image / File Upload Box */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {language === 'en' ? 'Prescription Slip Photo / PDF' : 'चिठ्ठीचा फोटो / फाईल'}
                </label>

                {previewImage ? (
                  <div className="relative rounded-xl border border-slate-200 overflow-hidden bg-slate-50 p-2">
                    <img 
                      src={previewImage} 
                      alt="Prescription preview" 
                      className="w-full max-h-48 object-contain rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => setPreviewImage(null)}
                      className="absolute top-3 right-3 bg-red-600 text-white text-xs px-2.5 py-1 rounded-md shadow-sm hover:bg-red-700 transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-slate-300 rounded-xl p-5 text-center hover:border-emerald-500 transition-colors bg-slate-50/50">
                    <Upload className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                    <p className="text-xs font-medium text-slate-700">
                      Click to upload doctor's slip photo (JPG, PNG or PDF)
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Clear photo showing Doctor Name, Patient Name & Medicine List
                    </p>
                    
                    <div className="mt-3 flex items-center justify-center gap-2">
                      <label className="cursor-pointer px-3.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 shadow-xs">
                        <span>Browse File</span>
                        <input 
                          type="file" 
                          accept="image/*,.pdf" 
                          onChange={handleImageChange} 
                          className="hidden" 
                        />
                      </label>
                      
                      <button
                        type="button"
                        onClick={loadDemoPrescription}
                        className="px-3.5 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold hover:bg-emerald-100 transition-colors"
                      >
                        ⚡ Try Sample Doctor Slip
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Patient Details Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Patient Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="e.g. Ramesh Patil"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Patient Age
                  </label>
                  <input
                    type="text"
                    value={patientAge}
                    onChange={(e) => setPatientAge(e.target.value)}
                    placeholder="e.g. 45"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mobile Phone (WhatsApp) *
                  </label>
                  <input
                    type="tel"
                    required
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    placeholder="e.g. 9822012345"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600 bg-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Village / Town (Radhanagri Area)
                  </label>
                  <select
                    value={village}
                    onChange={(e) => setVillage(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600 bg-white"
                  >
                    <option value="Kasba Tarle">Kasba Tarle (416211)</option>
                    <option value="Radhanagri Town">Radhanagri Town (416212)</option>
                    <option value="Walur">Walur (416211)</option>
                    <option value="Solankur">Solankur (416212)</option>
                    <option value="Fejivade">Fejivade (416212)</option>
                    <option value="Shiroli Dhangerwadi">Shiroli Dhangerwadi (416211)</option>
                    <option value="Other Kolhapur Rural">Other Kolhapur Village</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Doctor's Name & Clinic (Optional)
                </label>
                <input
                  type="text"
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  placeholder="e.g. Dr. Patil Clinic, Tarle"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Special Notes for Pharmacist
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Please send generic substitutes to save cost, or urgent 2-hour delivery required..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600 bg-white"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row gap-2.5">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit for Pharmacist Review</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendToWhatsApp}
                  className="py-2.5 px-4 bg-green-600 hover:bg-green-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Send on WhatsApp</span>
                </button>
              </div>

            </form>
          </div>
        ) : (
          /* Submission Confirmation & Live Order Tracker */
          <div className="py-4 text-center">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-bold text-slate-900 font-display">
              Prescription Successfully Submitted!
            </h3>
            <p className="text-xs text-slate-600 mt-1 max-w-md mx-auto">
              Our registered pharmacist at Sadguru Medical (Kasba Tarle) is reviewing your doctor slip. We will call you on <strong className="font-mono text-slate-800">{patientPhone}</strong> to confirm dosage and price before dispatch.
            </p>

            {/* Generated Order Token */}
            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl inline-block text-left">
              <div className="text-[11px] text-slate-500 font-medium">Prescription Reference ID:</div>
              <div className="text-base font-bold font-mono text-emerald-800">{orderRef}</div>
              <div className="text-[11px] text-slate-500 mt-1">Delivery to: {village}, Tal. Radhanagri</div>
            </div>

            {/* Live Progress Milestones */}
            <div className="mt-6 border-t border-slate-200 pt-5 text-left">
              <div className="text-xs font-bold text-slate-800 mb-3 uppercase tracking-wider">
                Live Order Milestones:
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-xs text-emerald-800 font-medium">
                  <div className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px] font-bold">1</div>
                  <span>Prescription Uploaded · Logged into Sadguru Medical Dispensary System</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-emerald-800 font-medium">
                  <div className="w-5 h-5 rounded-full bg-emerald-700 text-white flex items-center justify-center text-[10px] font-bold">2</div>
                  <span>B.Pharm Pharmacist Reviewing & Verifying Drug Dosage</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <div className="w-5 h-5 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center text-[10px] font-bold">3</div>
                  <span>Medicine Packing & Dispatch from Kasba Tarle Store</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <div className="w-5 h-5 rounded-full bg-slate-200 text-slate-500 flex items-center justify-center text-[10px] font-bold">4</div>
                  <span>Doorstep Delivery in {village} (30 - 45 mins)</span>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-center gap-3">
              <button
                onClick={resetForm}
                className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-lg text-xs font-semibold transition-colors"
              >
                Upload Another
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Done
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
