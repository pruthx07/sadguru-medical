/**
 * ==============================================================================
 * STORE CREDENTIALS, LOCAL RADHANAGRI VILLAGE COVERAGE & LOCATION
 * ==============================================================================
 *
 * [STUDENT PROJECT VIVA EXPLANATION]:
 * This section anchors the web application to the physical community of Kasba Tarle.
 * It features an interactive pincode/village delivery checker and official
 * regulatory disclosures (FDA License, Pharmacist council registration).
 */

import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Clock, 
  ShieldCheck, 
  Truck, 
  Search, 
  CheckCircle2, 
  AlertCircle,
  Building,
  Navigation
} from 'lucide-react';
import { SADGURU_STORE_INFO, DELIVERY_AREAS } from '../data/storeInfo';
import { Language } from '../data/translations';

interface StoreLocationSectionProps {
  language: Language;
}

export const StoreLocationSection: React.FC<StoreLocationSectionProps> = ({ language }) => {
  const [searchPincode, setSearchPincode] = useState('');
  const [matchedArea, setMatchedArea] = useState<typeof DELIVERY_AREAS[0] | null | 'not_found'>(null);

  const handleCheckDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchPincode.trim()) return;

    const term = searchPincode.trim().toLowerCase();
    const found = DELIVERY_AREAS.find(
      a => a.name.toLowerCase().includes(term) || a.pincode === term
    );

    if (found) {
      setMatchedArea(found);
    } else {
      setMatchedArea('not_found');
    }
  };

  return (
    <section id="store-info" className="py-14 bg-white border-t border-slate-200 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="max-w-2xl mb-10">
          <div className="flex items-center gap-2 text-emerald-800 text-xs font-semibold uppercase tracking-wider mb-1">
            <Building className="w-4 h-4 text-emerald-700" />
            <span>Community Pharmacy Headquarters</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            {language === 'en' ? 'Visit Sadguru Medical in Kasba Tarle' : 'सद्गुरु मेडिकल, कसबा तारळे - संपर्क व पत्ता'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Serving Kasba Tarle, Radhanagri taluka, and surrounding Kolhapur rural areas with genuine medicines and compassionate healthcare.
          </p>
        </div>

        {/* 2-Column Split: Credentials & Local Delivery Checker */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          
          {/* Column 1: Store Credentials Card */}
          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col justify-between">
            <div className="space-y-4">
              
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {SADGURU_STORE_INFO.name}
                </h3>
                <div className="text-xs font-semibold text-emerald-800">
                  {SADGURU_STORE_INFO.marathiName}
                </div>
              </div>

              {/* Exact Address */}
              <div className="flex items-start gap-3 text-xs text-slate-700">
                <MapPin className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-900">Physical Store Address:</div>
                  <div>At Post {SADGURU_STORE_INFO.address.village},</div>
                  <div>Taluka: {SADGURU_STORE_INFO.address.taluka}, District: {SADGURU_STORE_INFO.address.district},</div>
                  <div>{SADGURU_STORE_INFO.address.state} - Pin Code: <strong className="font-mono text-emerald-900">{SADGURU_STORE_INFO.address.pincode}</strong></div>
                  <div className="text-slate-500 mt-0.5">Landmark: {SADGURU_STORE_INFO.address.landmark}</div>
                </div>
              </div>

              {/* Operating Hours */}
              <div className="flex items-start gap-3 text-xs text-slate-700">
                <Clock className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-900">Store Timings:</div>
                  <div>{SADGURU_STORE_INFO.hours}</div>
                  <div className="text-emerald-700 font-semibold mt-0.5">
                    ⚡ 24x7 Emergency Call Service available for critical injections & oxygen kits
                  </div>
                </div>
              </div>

              {/* Regulatory License */}
              <div className="flex items-start gap-3 text-xs text-slate-700">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-900">Owner & Registered Pharmacist:</div>
                  <div className="text-emerald-900 font-bold">{SADGURU_STORE_INFO.ownerName}</div>
                  <div className="text-slate-600 text-[11px]">{SADGURU_STORE_INFO.degrees}</div>
                  <div className="text-slate-500 font-mono text-[11px] mt-0.5">
                    {SADGURU_STORE_INFO.licenseNumber}
                  </div>
                  <div className="text-slate-500 font-mono text-[11px]">
                    GSTIN: {SADGURU_STORE_INFO.gstin}
                  </div>
                </div>
              </div>

            </div>

            {/* Helpline Actions */}
            <div className="pt-4 border-t border-slate-200 mt-6 flex flex-wrap gap-2.5">
              <a
                href={`tel:${SADGURU_STORE_INFO.phones[0]}`}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shadow-xs"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Store: {SADGURU_STORE_INFO.phones[0]}</span>
              </a>

              <a
                href={`https://maps.google.com/?q=Kasba+Tarle+Radhanagri+Kolhapur+416211`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5 text-slate-600" />
                <span>Open in Google Maps</span>
              </a>
            </div>

          </div>

          {/* Column 2: Radhanagri Rural Delivery Checker */}
          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                <Truck className="w-4 h-4 text-emerald-700" />
                <span>Check Delivery Availability in Your Village:</span>
              </div>
              <p className="text-xs text-slate-500 mb-4">
                Enter your village name or pin code to verify delivery speed from our Kasba Tarle store.
              </p>

              {/* Delivery Search Form */}
              <form onSubmit={handleCheckDelivery} className="flex gap-2 mb-4">
                <input
                  type="text"
                  placeholder="e.g. Kasba Tarle, Walur, 416211..."
                  value={searchPincode}
                  onChange={(e) => setSearchPincode(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-emerald-600"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold transition-colors"
                >
                  Verify
                </button>
              </form>

              {/* Verification Outcome */}
              {matchedArea && matchedArea !== 'not_found' && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                    <span>Direct Home Delivery Available to {matchedArea.name}!</span>
                  </div>
                  <div>Pin Code: <strong className="font-mono">{matchedArea.pincode}</strong></div>
                  <div>Estimated Time: <strong>{matchedArea.deliveryTime}</strong></div>
                  <div className="text-[11px] text-emerald-800">
                    Free home delivery on medicine orders above ₹{matchedArea.freeAbove}.
                  </div>
                </div>
              )}

              {matchedArea === 'not_found' && (
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950 space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-amber-900">
                    <AlertCircle className="w-4 h-4 text-amber-700" />
                    <span>Special Rural Courier Delivery</span>
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Your location in Kolhapur district is covered via express courier or bus parcel service. Call our pharmacist at +91 98220 45678 to coordinate.
                  </p>
                </div>
              )}

              {/* Quick Village Pills for Instant Selection */}
              <div className="mt-5">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Common Village Delivery Routes:
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {DELIVERY_AREAS.map((area) => (
                    <button
                      key={area.name}
                      onClick={() => {
                        setSearchPincode(area.name);
                        setMatchedArea(area);
                      }}
                      className="px-2.5 py-1 text-[11px] font-medium bg-white hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200 rounded-md transition-colors"
                    >
                      {area.name} ({area.deliveryTime})
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 mt-6 pt-3 border-t border-slate-200">
              * Emergency delivery of vital insulin, asthma inhalers, and cardiac drugs available 24x7 within 15 km of Kasba Tarle.
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
