/**
 * ==============================================================================
 * TOP NAVIGATION BAR (Strict Top Bar Contract Architecture)
 * ==============================================================================
 *
 * [STUDENT PROJECT VIVA EXPLANATION]:
 * The Navbar provides primary orientation across the web application.
 * Following modern web accessibility standards, it follows a strict 3-zone layout:
 * 1. Brand Zone (Wordmark)
 * 2. Nav Links (Semantic anchor navigation)
 * 3. Primary Action (Shopping Cart drawer toggle + Language switcher)
 */

import React from 'react';
import { ShoppingBag, FileText, PhoneCall, Languages, ShieldCheck } from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { SADGURU_STORE_INFO } from '../data/storeInfo';

interface NavbarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  cartItemCount: number;
  onOpenCart: () => void;
  onOpenPrescription: () => void;
  activeSection: string;
  setActiveSection: (sec: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  language,
  setLanguage,
  cartItemCount,
  onOpenCart,
  onOpenPrescription,
  activeSection,
  setActiveSection,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs transition-all">
      {/* Top emergency & community notification ticker */}
      <div className="bg-emerald-800 text-emerald-50 text-xs py-1.5 px-4 text-center font-medium tracking-wide flex items-center justify-center gap-3">
        <span className="flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
          <span>{t.emergencyBanner}</span>
        </span>
        <span className="text-emerald-300/60 hidden sm:inline">|</span>
        <span className="hidden sm:inline font-mono">Lic. FDA MH-KOL-284910</span>
        <span className="text-emerald-300/60 hidden sm:inline">|</span>
        <a 
          href={`tel:${SADGURU_STORE_INFO.phones[0]}`} 
          className="underline hover:text-white transition-colors flex items-center gap-1"
        >
          <PhoneCall className="w-3 h-3" />
          <span>Emergency Call: {SADGURU_STORE_INFO.phones[0]}</span>
        </a>
      </div>

      {/* Main 3-Zone Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          
          {/* ZONE 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <a 
              href="#hero" 
              onClick={(e) => {
                e.preventDefault();
                setActiveSection('hero');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group flex items-center gap-2.5 text-left"
            >
              <div className="w-9 h-9 rounded-lg bg-emerald-700 text-white flex items-center justify-center font-bold text-lg shadow-sm group-hover:bg-emerald-800 transition-colors">
                <span className="text-emerald-100 font-display">स</span>
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold tracking-tight text-slate-900 font-display whitespace-nowrap">
                  Sadguru Medical
                </span>
                <span className="text-[11px] font-medium text-emerald-700 -mt-1 tracking-tight">
                  सद्गुरु मेडिकल · Kasba Tarle
                </span>
              </div>
            </a>
          </div>

          {/* ZONE 2: Clean Single-line Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a 
              href="#catalog" 
              onClick={() => setActiveSection('catalog')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 ${
                activeSection === 'catalog' ? 'text-emerald-700 font-semibold' : ''
              }`}
            >
              {t.navCatalog}
            </a>
            <button 
              onClick={onOpenPrescription}
              className="text-slate-600 hover:text-emerald-700 transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <FileText className="w-4 h-4 text-emerald-600" />
              <span>{t.navUploadRx}</span>
            </button>
            <a 
              href="#generic-saver" 
              onClick={() => setActiveSection('generic-saver')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 ${
                activeSection === 'generic-saver' ? 'text-emerald-700 font-semibold' : ''
              }`}
            >
              {t.navGenericSaver}
            </a>
            <a 
              href="#dose-tracker" 
              onClick={() => setActiveSection('dose-tracker')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 ${
                activeSection === 'dose-tracker' ? 'text-emerald-700 font-semibold' : ''
              }`}
            >
              {t.navDoseTracker}
            </a>
            <a 
              href="#store-info" 
              onClick={() => setActiveSection('store-info')}
              className={`whitespace-nowrap transition-colors hover:text-emerald-700 ${
                activeSection === 'store-info' ? 'text-emerald-700 font-semibold' : ''
              }`}
            >
              {t.navStoreInfo}
            </a>
          </nav>

          {/* ZONE 3: Primary Action & Localization */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Language Toggle Button */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'mr' : 'en')}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-md border border-slate-200 text-slate-700 hover:bg-slate-100 transition-colors flex items-center gap-1.5"
              title="Switch Language / भाषा बदला"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'en' ? 'मराठी' : 'English'}</span>
            </button>

            {/* Shopping Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors flex items-center gap-2 shadow-xs"
              aria-label="View Shopping Basket"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">{language === 'en' ? 'Basket' : 'बास्केट'}</span>
              {cartItemCount > 0 && (
                <span className="inline-flex items-center justify-center bg-white text-emerald-900 font-bold text-[11px] px-1.5 py-0.2 rounded-full min-w-5">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
