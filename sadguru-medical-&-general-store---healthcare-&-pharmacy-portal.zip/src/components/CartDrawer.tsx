/**
 * ==============================================================================
 * SHOPPING BASKET DRAWER & BILLING INVOICE CHECKOUT
 * ==============================================================================
 *
 * [STUDENT PROJECT EXPLANATION]:
 * This component handles the full ecommerce transactional workflow:
 * 1. Cart state reconciliation (subtotals, delivery fee thresholds, quantity mutations).
 * 2. Multi-mode payment gateway simulation (Cash on Delivery, UPI QR code, Counter Pickup).
 * 3. Generation of official Pharmacy Tax Invoice meeting Maharashtra FDA standards.
 */

import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  CreditCard, 
  QrCode, 
  MapPin, 
  ArrowRight, 
  Printer, 
  CheckCircle2, 
  ShieldCheck,
  PhoneCall
} from 'lucide-react';
import { CartItem } from '../types/pharmacy';
import { Language } from '../data/translations';
import { SADGURU_STORE_INFO } from '../data/storeInfo';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (medicineId: string, delta: number) => void;
  onRemoveItem: (medicineId: string) => void;
  onClearCart: () => void;
  language: Language;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  language,
}) => {
  // Checkout flow state
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryVillage, setDeliveryVillage] = useState('Kasba Tarle');
  const [addressLine, setAddressLine] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'upi' | 'pickup'>('cod');
  const [invoiceNumber, setInvoiceNumber] = useState('');

  if (!isOpen) return null;

  // Calculate pricing math
  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.medicine.sellingPrice * item.quantity,
    0
  );
  const mrpTotal = cartItems.reduce(
    (sum, item) => sum + item.medicine.mrp * item.quantity,
    0
  );
  const totalSavings = mrpTotal - subtotal;
  
  // Delivery rule: Free for Kasba Tarle over ₹200; otherwise ₹30
  const deliveryFee = subtotal >= 200 || paymentMethod === 'pickup' ? 0 : 30;
  const grandTotal = subtotal + deliveryFee;

  // Handle final checkout placement
  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone) return;

    const randomInv = `INV-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    setInvoiceNumber(randomInv);
    setStep('success');
  };

  // WhatsApp order dispatch
  const handleOrderViaWhatsApp = () => {
    const itemList = cartItems
      .map(i => `• ${i.medicine.name} x ${i.quantity} (₹${(i.medicine.sellingPrice * i.quantity).toFixed(2)})`)
      .join('\n');

    const message = encodeURIComponent(
      `*New Medicine Order - Sadguru Medical Kasba Tarle*\n\n` +
      `*Customer:* ${customerName || 'Patient'}\n` +
      `*Phone:* ${customerPhone || 'Direct'}\n` +
      `*Delivery Area:* ${deliveryVillage}, Tal. Radhanagri, Kolhapur\n` +
      `*Payment:* ${paymentMethod.toUpperCase()}\n\n` +
      `*Medicines Requested:*\n${itemList}\n\n` +
      `*Grand Total:* ₹${grandTotal.toFixed(2)}\n\n` +
      `Please confirm stock availability and dispatch time.`
    );
    window.open(`https://wa.me/${SADGURU_STORE_INFO.whatsapp}?text=${message}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs transition-opacity">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl relative text-left">
        
        {/* Header Strip */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-slate-900 text-lg font-display">
              {step === 'cart' && (language === 'en' ? 'Your Medicine Basket' : 'तुमची औषध बास्केट')}
              {step === 'checkout' && (language === 'en' ? 'Checkout & Delivery' : 'डिलिव्हरी पत्ता व पेमेंट')}
              {step === 'success' && (language === 'en' ? 'Order Invoice' : 'औषध खरेदी पावती')}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: CART ITEMS VIEW */}
        {step === 'cart' && (
          <div className="flex-1 flex flex-col justify-between overflow-hidden">
            {cartItems.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mb-3">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="text-base font-bold text-slate-700">Your basket is empty</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">
                  Browse our Kasba Tarle pharmacy catalog or upload your prescription to add medicines.
                </p>
                <button
                  onClick={onClose}
                  className="mt-5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold"
                >
                  Browse Medicines
                </button>
              </div>
            ) : (
              <>
                {/* Scrollable Items List */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {cartItems.map((item) => (
                    <div 
                      key={item.medicine.id}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-slate-900 truncate">
                          {language === 'mr' ? item.medicine.marathiName : item.medicine.name}
                        </h4>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          {item.medicine.packSize}
                        </div>
                        <div className="text-xs font-bold text-slate-800 font-mono tabular-nums mt-1">
                          ₹{(item.medicine.sellingPrice * item.quantity).toFixed(2)}
                        </div>
                      </div>

                      {/* Quantity Stepper */}
                      <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg p-0.5">
                        <button
                          onClick={() => onUpdateQuantity(item.medicine.id, -1)}
                          className="p-1 text-slate-500 hover:text-slate-800 rounded"
                          aria-label="Decrease"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold font-mono text-slate-800">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.medicine.id, 1)}
                          className="p-1 text-slate-500 hover:text-slate-800 rounded"
                          aria-label="Increase"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => onRemoveItem(item.medicine.id)}
                        className="text-slate-400 hover:text-red-600 p-1"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Bill Summary & Proceed */}
                <div className="p-4 bg-slate-50 border-t border-slate-200 space-y-2">
                  <div className="flex justify-between text-xs text-slate-600">
                    <span>Items Total (MRP):</span>
                    <span className="font-mono tabular-nums">₹{mrpTotal.toFixed(2)}</span>
                  </div>

                  {totalSavings > 0 && (
                    <div className="flex justify-between text-xs text-emerald-700 font-semibold">
                      <span>Total Savings:</span>
                      <span className="font-mono tabular-nums">-₹{totalSavings.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-xs text-slate-600">
                    <span>Delivery in Kasba Tarle:</span>
                    <span className="font-mono tabular-nums">
                      {deliveryFee === 0 ? (
                        <span className="text-emerald-700 font-semibold">FREE (Above ₹200)</span>
                      ) : (
                        `₹${deliveryFee.toFixed(2)}`
                      )}
                    </span>
                  </div>

                  <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-slate-200">
                    <span>To Pay:</span>
                    <span className="font-mono text-base text-emerald-800">
                      ₹{grandTotal.toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={() => setStep('checkout')}
                    className="w-full mt-3 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-2 shadow-xs"
                  >
                    <span>Proceed to Delivery & Payment</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* STEP 2: CHECKOUT DETAILS VIEW */}
        {step === 'checkout' && (
          <form onSubmit={handlePlaceOrder} className="flex-1 flex flex-col justify-between overflow-y-auto p-4">
            <div className="space-y-4">
              
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                1. Delivery Location:
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Recipient Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dattatray Patil"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mobile Number (for delivery call & SMS) *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9822012345"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Village / Area (Radhanagri Region)
                </label>
                <select
                  value={deliveryVillage}
                  onChange={(e) => setDeliveryVillage(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600"
                >
                  <option value="Kasba Tarle">Kasba Tarle (Store Home Delivery - Free)</option>
                  <option value="Radhanagri Town">Radhanagri Town (416212)</option>
                  <option value="Walur">Walur Village (416211)</option>
                  <option value="Solankur">Solankur (416212)</option>
                  <option value="Fejivade">Fejivade</option>
                  <option value="Other Kolhapur">Other Kolhapur Rural</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Street / House Landmark
                </label>
                <input
                  type="text"
                  placeholder="Near Tarle Grampanchayat / Temple"
                  value={addressLine}
                  onChange={(e) => setAddressLine(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider pt-2">
                2. Select Payment Method:
              </div>

              <div className="space-y-2">
                <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer text-xs transition-colors ${
                  paymentMethod === 'cod' ? 'border-emerald-600 bg-emerald-50/50' : 'border-slate-200'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                    className="accent-emerald-700"
                  />
                  <div>
                    <span className="font-bold text-slate-900 block">Cash on Delivery (COD)</span>
                    <span className="text-slate-500 text-[11px]">Pay cash upon home delivery</span>
                  </div>
                </label>

                <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer text-xs transition-colors ${
                  paymentMethod === 'upi' ? 'border-emerald-600 bg-emerald-50/50' : 'border-slate-200'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'upi'}
                    onChange={() => setPaymentMethod('upi')}
                    className="accent-emerald-700"
                  />
                  <div>
                    <span className="font-bold text-slate-900 block">Instant UPI / QR Code</span>
                    <span className="text-slate-500 text-[11px]">PhonePe, Google Pay, Paytm</span>
                  </div>
                </label>

                <label className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer text-xs transition-colors ${
                  paymentMethod === 'pickup' ? 'border-emerald-600 bg-emerald-50/50' : 'border-slate-200'
                }`}>
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'pickup'}
                    onChange={() => setPaymentMethod('pickup')}
                    className="accent-emerald-700"
                  />
                  <div>
                    <span className="font-bold text-slate-900 block">Store Counter Pickup</span>
                    <span className="text-slate-500 text-[11px]">Collect from Sadguru Medical Kasba Tarle</span>
                  </div>
                </label>
              </div>

            </div>

            <div className="pt-4 border-t border-slate-200 mt-6 space-y-2">
              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <span>Confirm Order (Pay ₹{grandTotal.toFixed(2)})</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setStep('cart')}
                className="w-full py-2 text-xs text-slate-500 hover:text-slate-800 font-medium"
              >
                ← Back to Basket
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: ORDER SUCCESS & PRINTABLE TAX INVOICE */}
        {step === 'success' && (
          <div className="flex-1 flex flex-col justify-between overflow-y-auto p-4">
            
            {/* Printable Receipt Container */}
            <div id="printable-invoice" className="p-4 bg-white border border-slate-200 rounded-xl space-y-4">
              
              {/* Store Official Letterhead */}
              <div className="text-center border-b border-slate-200 pb-3">
                <h2 className="font-black text-slate-900 text-base font-display">
                  SADGURU MEDICAL & GENERAL STORE
                </h2>
                <div className="text-[11px] text-slate-600">
                  At Post Kasba Tarle, Tal. Radhanagri, Dist. Kolhapur - 416211
                </div>
                <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                  FDA Lic: MH-KOL-284910 · GSTIN: 27AABCS9876Q1Z2
                </div>
                <div className="text-[10px] text-emerald-800 font-medium">
                  Proprietor: {SADGURU_STORE_INFO.ownerName} · Reg. Pharmacist (MSPC: 184592)
                </div>
              </div>

              {/* Order & Customer Metadata */}
              <div className="flex justify-between text-[11px] text-slate-600 border-b border-slate-100 pb-2">
                <div>
                  <div>Invoice: <strong className="font-mono text-slate-900">{invoiceNumber}</strong></div>
                  <div>Date: {new Date().toLocaleDateString('en-IN')}</div>
                </div>
                <div className="text-right">
                  <div>Patient: <strong className="text-slate-900">{customerName}</strong></div>
                  <div>Area: {deliveryVillage}</div>
                </div>
              </div>

              {/* Itemized Table */}
              <div className="space-y-1.5 text-xs">
                {cartItems.map((item) => (
                  <div key={item.medicine.id} className="flex justify-between text-slate-700">
                    <span className="truncate max-w-[200px]">
                      {item.medicine.name} x {item.quantity}
                    </span>
                    <span className="font-mono tabular-nums">
                      ₹{(item.medicine.sellingPrice * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Total Row */}
              <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-sm text-slate-900">
                <span>Grand Total:</span>
                <span className="font-mono text-emerald-800">₹{grandTotal.toFixed(2)}</span>
              </div>

              <div className="text-[10px] text-center text-slate-400 italic">
                Thank you for choosing Sadguru Medical! Wishing you good health.
              </div>

            </div>

            {/* Action Bar */}
            <div className="pt-4 border-t border-slate-200 space-y-2 mt-4">
              <button
                type="button"
                onClick={() => window.print()}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Tax Invoice</span>
              </button>

              <button
                type="button"
                onClick={handleOrderViaWhatsApp}
                className="w-full py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Send Invoice on WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onClearCart();
                  onClose();
                  setStep('cart');
                }}
                className="w-full py-2 text-xs text-slate-500 hover:text-slate-800 font-medium"
              >
                Done / Back to Store
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
