/**
 * ==============================================================================
 * HERO SECTION & QUICK HEALTHCARE ACTION HUB
 * ==============================================================================
 *
 * [STUDENT PROJECT EXPLANATION]:
 * The Hero section creates the initial impression of credibility and emergency
 * readiness. It equips customers with immediate search capabilities,
 * live prescription upload triggers, and clear local store identity
 * (Kasba Tarle, Radhanagri, Kolhapur).
 */

import React from 'react';
import { 
  Search, 
  Upload, 
  Sparkles, 
  Truck, 
  PhoneCall, 
  CheckCircle2, 
  Building2, 
  Clock, 
  ShieldCheck, 
  ArrowRight,
  MessageCircle
} from 'lucide-react';
import { Language, TRANSLATIONS } from '../data/translations';
import { SADGURU_STORE_INFO } from '../data/storeInfo';

interface HeroSectionProps {
  language: Language;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onOpenPrescription: () => void;
  onOpenGenericSaver: () => void;
  onNavigateToCatalog: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  language,
  searchQuery,
  setSearchQuery,
  onOpenPrescription,
  onOpenGenericSaver,
  onNavigateToCatalog,
}) => {
  const t = TRANSLATIONS[language];

  // Helper to trigger WhatsApp ordering
  const handleWhatsAppDirect = () => {
    const text = encodeURIComponent(
      `Hello Sadguru Medical, I want to order medicines for delivery in Kasba Tarle / Radhanagri. Please assist me.`
    );
    window.open(`https://wa.me/${SADGURU_STORE_INFO.whatsapp}?text=${text}`, '_blank');
  };

  return (
    <section id="hero" className="relative overflow-hidden bg-gradient-to-b from-emerald-50/70 via-white to-slate-50 pt-8 pb-14 border-b border-slate-200">
      
      {/* Background architectural aura */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-200/30 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-teal-200/20 rounded-full blur-3xl pointer-events-none -ml-20" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Location Trust Tag (Clean Unboxed Typography) */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-emerald-800 mb-4">
          <span className="flex items-center gap-1 font-semibold">
            <Building2 className="w-3.5 h-3.5 text-emerald-700" />
            <span>Kasba Tarle, Tal. Radhanagri</span>
          </span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>Kolhapur - 416211</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span className="text-slate-600">Registered Pharmacist On Duty</span>
        </div>

        {/* Hero Title & Subtitle */}
        <div className="max-w-3xl mb-8">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight font-display text-balance leading-tight">
            {language === 'en' ? (
              <>
                Kasba Tarle's Trusted <span className="text-emerald-700">24x7 Healthcare</span> & Medicine Store
              </>
            ) : (
              <>
                कसबा तारळे व राधानगरी परिसराची हक्काची <span className="text-emerald-700">२४x७ औषध सेवा</span>
              </>
            )}
          </h1>
          <p className="mt-3 text-base sm:text-lg text-slate-600 leading-relaxed">
            {language === 'en'
              ? 'Get 100% genuine medicines, verified doctor prescription fulfillment, bio-equivalent generic substitutes, and express rural home delivery straight to your doorstep.'
              : '१००% खात्रीशीर ब्रँडेड व जेनेरिक औषधे, डॉक्टरांच्या चिठ्ठीनुसार त्वरित घरपोच डिलिव्हरी आणि अनुभवी फार्मासिस्टचे मोफत मार्गदर्शन.'}
          </p>
        </div>

        {/* Unified Search Bar & Autocomplete Input */}
        <div className="max-w-2xl bg-white p-2 rounded-2xl shadow-md border border-slate-200/80 mb-8 flex flex-col sm:flex-row gap-2">
          <div className="flex-1 flex items-center px-3 gap-2.5">
            <Search className="w-5 h-5 text-emerald-600 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full py-2.5 text-sm sm:text-base text-slate-800 placeholder-slate-400 bg-transparent focus:outline-none"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="text-xs text-slate-400 hover:text-slate-600 px-2 py-1"
              >
                Clear
              </button>
            )}
          </div>
          <button
            onClick={onNavigateToCatalog}
            className="px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm rounded-xl transition-colors shrink-0 flex items-center justify-center gap-2 shadow-xs"
          >
            <span>{language === 'en' ? 'Find Medicine' : 'औषध शोधा'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 4 Interactive Service Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          
          {/* Card 1: Prescription Upload */}
          <div 
            onClick={onOpenPrescription}
            className="group cursor-pointer bg-white p-5 rounded-xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all relative overflow-hidden"
          >
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Upload className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
              {language === 'en' ? 'Upload Prescription' : 'प्रिस्क्रिप्शन अपलोड'}
            </h2>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              {language === 'en'
                ? 'Send doctor slip photo. Pharmacist packs and dispatches promptly.'
                : 'डॉक्टरांच्या चिठ्ठीचा फोटो पाठवा. फार्मासिस्ट तपासून त्वरित औषध देतील.'}
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 mt-3">
              <span>{language === 'en' ? 'Upload Slip' : 'अपलोड करा'}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
          </div>

          {/* Card 2: Generic Price Saver */}
          <div 
            onClick={onOpenGenericSaver}
            className="group cursor-pointer bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-500 hover:shadow-md transition-all relative overflow-hidden"
          >
            <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
              {language === 'en' ? 'Generic Price Saver' : 'जेनेरिक औषध बचत'}
            </h2>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              {language === 'en'
                ? 'Find exact chemical salt alternatives and save up to 80% on monthly bills.'
                : 'समान घटकांचे जेनेरिक पर्याय तपासा आणि महिन्याच्या बिलात ८०% बचत करा.'}
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 mt-3">
              <span>{language === 'en' ? 'Compare Salts' : 'बचत मोजा'}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
          </div>

          {/* Card 3: WhatsApp Quick Order */}
          <div 
            onClick={handleWhatsAppDirect}
            className="group cursor-pointer bg-white p-5 rounded-xl border border-slate-200 hover:border-green-500 hover:shadow-md transition-all relative overflow-hidden"
          >
            <div className="w-10 h-10 rounded-lg bg-green-100 text-green-800 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <MessageCircle className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-slate-900 group-hover:text-green-700 transition-colors">
              {language === 'en' ? 'Order on WhatsApp' : 'व्हॉट्सअॅपवर ऑर्डर'}
            </h2>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              {language === 'en'
                ? `Directly message Sadguru Medical at ${SADGURU_STORE_INFO.phones[0]} for instant response.`
                : 'थेट व्हॉट्सअॅपवर औषधांची यादी पाठवून घरपोच मिळवा.'}
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-green-700 mt-3">
              <span>{language === 'en' ? 'Chat Now' : 'चॅट सुरू करा'}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
          </div>

          {/* Card 4: Local Village Delivery */}
          <div 
            onClick={() => {
              const el = document.getElementById('store-info');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="group cursor-pointer bg-white p-5 rounded-xl border border-slate-200 hover:border-amber-500 hover:shadow-md transition-all relative overflow-hidden"
          >
            <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Truck className="w-5 h-5" />
            </div>
            <h2 className="text-base font-bold text-slate-900 group-hover:text-amber-700 transition-colors">
              {language === 'en' ? 'Tarle & Radhanagri Delivery' : 'स्थानिक जलद डिलिव्हरी'}
            </h2>
            <p className="text-xs text-slate-500 mt-1 line-clamp-2">
              {language === 'en'
                ? 'Delivery in 30-45 mins across Kasba Tarle, Walur, Solankur & Radhanagri.'
                : 'कसबा तारळे, वाळूर, सोळांकूर व राधानगरी भागात ३० ते ४५ मिनिटांत डिलिव्हरी.'}
            </p>
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 mt-3">
              <span>{language === 'en' ? 'View Pin Codes' : 'पिन कोड तपासा'}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
          </div>

        </div>

        {/* Clinical Proof & Authority Strip (Adjacency Rule) */}
        <div className="bg-slate-100/90 rounded-xl p-4 border border-slate-200/80 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-700">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>100% Genuine Medicines Direct from Certified Pharma Depots</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>7:00 AM – 11:00 PM Active Counter · 24x7 Emergency Line</span>
          </div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Govt. FDA License No: MH-KOL-284910</span>
          </div>
        </div>

      </div>
    </section>
  );
};
