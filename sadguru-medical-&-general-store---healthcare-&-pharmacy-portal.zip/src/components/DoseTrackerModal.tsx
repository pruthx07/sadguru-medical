/**
 * ==============================================================================
 * DAILY PILL & DOSAGE SCHEDULE TRACKER
 * ==============================================================================
 *
 * [STUDENT PROJECT ACADEMIC HIGHLIGHT]:
 * Medication non-adherence is a major cause of preventable hospitalizations.
 * This tool empowers families in rural and suburban communities to organize
 * their daily medicine doses, track completion, and print an easy refrigerator chart.
 */

import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Check, 
  Plus, 
  Clock, 
  Printer, 
  Trash2, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { DosageReminder } from '../types/pharmacy';
import { Language } from '../data/translations';

interface DoseTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

// Initial realistic default schedule for demo
const INITIAL_REMINDERS: DosageReminder[] = [
  {
    id: 'dose-1',
    medicineName: 'Pantocid 40mg (Empty Stomach)',
    dosage: '1 Tablet',
    timing: ['Morning'],
    mealRelation: 'Before Food',
    daysLeft: 14,
    isTakenToday: true,
  },
  {
    id: 'dose-2',
    medicineName: 'Glycomet-GP 1 (Diabetes)',
    dosage: '1 Tablet',
    timing: ['Morning'],
    mealRelation: 'With Food',
    daysLeft: 28,
    isTakenToday: false,
  },
  {
    id: 'dose-3',
    medicineName: 'Telma 40mg (Blood Pressure)',
    dosage: '1 Tablet',
    timing: ['Morning'],
    mealRelation: 'After Food',
    daysLeft: 25,
    isTakenToday: false,
  },
  {
    id: 'dose-4',
    medicineName: 'Shelcal 500 (Calcium + D3)',
    dosage: '1 Tablet',
    timing: ['Night'],
    mealRelation: 'After Food',
    daysLeft: 10,
    isTakenToday: false,
  },
];

export const DoseTrackerModal: React.FC<DoseTrackerModalProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const [reminders, setReminders] = useState<DosageReminder[]>(INITIAL_REMINDERS);
  const [newMedName, setNewMedName] = useState('');
  const [newDosage, setNewDosage] = useState('1 Tablet');
  const [newMealRelation, setNewMealRelation] = useState<'Before Food' | 'After Food' | 'With Food'>('After Food');
  const [newTiming, setNewTiming] = useState<'Morning' | 'Afternoon' | 'Night'>('Morning');

  if (!isOpen) return null;

  // Toggle dose taken state
  const handleToggleTaken = (id: string) => {
    setReminders(prev =>
      prev.map(item =>
        item.id === id ? { ...item, isTakenToday: !item.isTakenToday } : item
      )
    );
  };

  // Add new medicine reminder
  const handleAddReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMedName.trim()) return;

    const newEntry: DosageReminder = {
      id: `dose-${Date.now()}`,
      medicineName: newMedName.trim(),
      dosage: newDosage,
      timing: [newTiming],
      mealRelation: newMealRelation,
      daysLeft: 15,
      isTakenToday: false,
    };

    setReminders(prev => [...prev, newEntry]);
    setNewMedName('');
  };

  // Delete dose reminder
  const handleDeleteReminder = (id: string) => {
    setReminders(prev => prev.filter(item => item.id !== id));
  };

  // Calculate compliance percentage
  const takenCount = reminders.filter(r => r.isTakenToday).length;
  const totalCount = reminders.length;
  const compliancePercent = totalCount > 0 ? Math.round((takenCount / totalCount) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 relative my-8 text-left">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          aria-label="Close Dosage Tracker"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 text-emerald-800 text-xs font-semibold uppercase tracking-wider mb-1">
            <Clock className="w-4 h-4 text-emerald-700" />
            <span>Daily Patient Medication Chart</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 font-display">
            {language === 'en' ? 'Pill & Dosage Schedule Tracker' : 'दैनंदिन गोळ्या व डोस स्मरणपत्र'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Track daily medications for yourself or elderly family members. Never miss a morning or bedtime dose.
          </p>
        </div>

        {/* Progress & Compliance Bar */}
        <div className="bg-emerald-50 border border-emerald-200/80 p-4 rounded-xl mb-6 flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-emerald-900">
              Today's Adherence Score: {takenCount} of {totalCount} Doses Completed
            </div>
            <div className="w-48 bg-emerald-200 h-2.5 rounded-full overflow-hidden mt-1.5">
              <div 
                className="bg-emerald-700 h-full rounded-full transition-all duration-500" 
                style={{ width: `${compliancePercent}%` }} 
              />
            </div>
          </div>
          <div className="text-2xl font-black font-mono text-emerald-800">
            {compliancePercent}%
          </div>
        </div>

        {/* Today's Medicine Checklist */}
        <div className="space-y-2.5 mb-6 max-h-64 overflow-y-auto pr-1">
          {reminders.map((reminder) => (
            <div
              key={reminder.id}
              onClick={() => handleToggleTaken(reminder.id)}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                reminder.isTakenToday
                  ? 'bg-slate-50/70 border-slate-200 text-slate-400'
                  : 'bg-white border-slate-200 hover:border-emerald-500 shadow-xs'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-6 h-6 rounded-md flex items-center justify-center transition-colors ${
                    reminder.isTakenToday
                      ? 'bg-emerald-700 text-white'
                      : 'border-2 border-slate-300 bg-white'
                  }`}
                >
                  {reminder.isTakenToday && <Check className="w-4 h-4" />}
                </div>

                <div>
                  <div className={`text-sm font-bold ${reminder.isTakenToday ? 'line-through text-slate-500' : 'text-slate-900'}`}>
                    {reminder.medicineName}
                  </div>
                  <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                    <span>{reminder.dosage}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-semibold text-emerald-800">{reminder.timing.join(', ')}</span>
                    <span aria-hidden="true">·</span>
                    <span>{reminder.mealRelation}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteReminder(reminder.id);
                }}
                className="text-slate-400 hover:text-red-600 p-1 transition-colors"
                title="Remove reminder"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Add New Dose Form */}
        <form onSubmit={handleAddReminder} className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 mb-5">
          <div className="text-xs font-bold text-slate-800 mb-2">
            + Add Medicine to Schedule:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            <input
              type="text"
              required
              placeholder="Medicine Name (e.g. Liv.52)"
              value={newMedName}
              onChange={(e) => setNewMedName(e.target.value)}
              className="sm:col-span-2 px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-emerald-600"
            />
            <select
              value={newTiming}
              onChange={(e) => setNewTiming(e.target.value as any)}
              className="px-2 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none"
            >
              <option value="Morning">Morning</option>
              <option value="Afternoon">Afternoon</option>
              <option value="Night">Night</option>
            </select>
            <button
              type="submit"
              className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors"
            >
              Add Dose
            </button>
          </div>
        </form>

        {/* Footer Actions */}
        <div className="flex items-center justify-between border-t border-slate-200 pt-3">
          <button
            onClick={() => window.print()}
            className="text-xs font-semibold text-slate-700 hover:text-emerald-800 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-50 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Medication Chart</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
