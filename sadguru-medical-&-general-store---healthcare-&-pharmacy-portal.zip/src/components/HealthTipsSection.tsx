/**
 * ==============================================================================
 * COMMUNITY HEALTH & FIRST AID ADVISORY GUIDES
 * ==============================================================================
 *
 * [STUDENT PROJECT EXPLANATION]:
 * Demonstrates public health awareness and community value in rural Maharashtra.
 * Features clinical protocols vetted by healthcare standards (CDSCO, WHO).
 */

import React, { useState } from 'react';
import { 
  HeartHandshake, 
  AlertTriangle, 
  Activity, 
  Droplet, 
  Sun, 
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { Language } from '../data/translations';

interface HealthTipsSectionProps {
  language: Language;
}

const HEALTH_ARTICLES = [
  {
    id: 'tip-1',
    category: 'Emergency Rural First Aid',
    title: 'Snake Bite Emergency Protocol (Radhanagri / Ghat Area)',
    marathiTitle: 'सर्पदंश प्रथमोपचार - काय करावे आणि काय करू नये?',
    summary: 'Essential life-saving steps before reaching the civil hospital. Critical for farmers and rural residents.',
    dos: [
      'Keep the patient calm and completely still to slow venom circulation.',
      'Immobilize the bitten limb using a splint or firm bandage (like a fracture).',
      'Immediately transport to Radhanagri Rural Hospital or CPR Hospital Kolhapur for Anti-Snake Venom (ASV).'
    ],
    donts: [
      'DO NOT cut or incise the bite wound.',
      'DO NOT attempt to suck venom by mouth.',
      'DO NOT apply tight tourniquets or ice packs (causes tissue necrosis).'
    ],
    icon: 'AlertTriangle',
    color: 'border-red-200 bg-red-50/40 text-red-900'
  },
  {
    id: 'tip-2',
    category: 'Chronic Disease Management',
    title: 'How to Accurately Measure Blood Pressure at Home',
    marathiTitle: 'घरी अचूक रक्तदाब (BP) तपासण्याची योग्य पद्धत',
    summary: 'Guidelines to avoid white-coat syndrome and inaccurate high blood pressure readings.',
    dos: [
      'Rest quietly for 5 minutes before taking the measurement.',
      'Sit on a chair with back supported and feet flat on the floor.',
      'Place the cuff on bare upper arm at heart level.'
    ],
    donts: [
      'Do not consume tea, coffee, or smoke 30 minutes before testing.',
      'Do not talk or move during the automatic cuff inflation.'
    ],
    icon: 'Activity',
    color: 'border-blue-200 bg-blue-50/40 text-blue-900'
  },
  {
    id: 'tip-3',
    category: 'Seasonal Care',
    title: 'Fever & Dehydration: When to Use ORS vs Painkillers',
    marathiTitle: 'ताप व डिहायड्रेशन: इलेक्ट्रॉल ओआरएस आणि डोलोचा योग्य वापर',
    summary: 'How to manage viral fever safely and avoid dangerous NSAID complications.',
    dos: [
      'Mix 1 full sachet of WHO-formula ORS in exactly 1 liter of boiled and cooled drinking water.',
      'Take Paracetamol (Dolo 650) for high fever, spacing doses by at least 6 hours.',
      'Maintain high fluid intake with coconut water, buttermilk, and clean water.'
    ],
    donts: [
      'DO NOT take Brufen/Combiflam or Aspirin if dengue is suspected (causes internal bleeding risk).',
      'Do not self-prescribe antibiotics for ordinary viral common cold.'
    ],
    icon: 'Droplet',
    color: 'border-emerald-200 bg-emerald-50/40 text-emerald-900'
  }
];

export const HealthTipsSection: React.FC<HealthTipsSectionProps> = ({ language }) => {
  const [activeArticle, setActiveArticle] = useState<string>(HEALTH_ARTICLES[0].id);

  const selected = HEALTH_ARTICLES.find(a => a.id === activeArticle) || HEALTH_ARTICLES[0];

  return (
    <section id="health-guides" className="py-14 bg-slate-50 border-t border-slate-200 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-8">
          <div className="flex items-center gap-2 text-emerald-800 text-xs font-semibold uppercase tracking-wider mb-1">
            <HeartHandshake className="w-4 h-4 text-emerald-700" />
            <span>Pharmacist Health Education</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
            {language === 'en' ? 'Community Health & First Aid Guides' : 'आरोग्य माहिती व प्रथमोपचार मार्गदर्शन'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Verified medical advice prepared by Sadguru Medical pharmacists for families in Kasba Tarle.
          </p>
        </div>

        {/* 2-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: Article Tabs */}
          <div className="space-y-2.5">
            {HEALTH_ARTICLES.map((article) => (
              <button
                key={article.id}
                onClick={() => setActiveArticle(article.id)}
                className={`w-full p-4 rounded-xl text-left border transition-all ${
                  article.id === selected.id
                    ? 'bg-white border-emerald-600 shadow-sm'
                    : 'bg-white/60 border-slate-200 hover:bg-white text-slate-600'
                }`}
              >
                <div className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wider">
                  {article.category}
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                  {language === 'mr' ? article.marathiTitle : article.title}
                </h4>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                  {article.summary}
                </p>
              </button>
            ))}
          </div>

          {/* Right Column: Detailed Clinical Protocol Card */}
          <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
            <div className="mb-4">
              <span className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">
                {selected.category}
              </span>
              <h3 className="text-xl font-bold text-slate-900 mt-1 font-display">
                {language === 'mr' ? selected.marathiTitle : selected.title}
              </h3>
              <p className="text-xs text-slate-600 mt-1">
                {selected.summary}
              </p>
            </div>

            {/* Dos and Don'ts Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
              
              {/* Mandatory DOs */}
              <div className="bg-emerald-50/70 p-4 rounded-xl border border-emerald-200">
                <div className="text-xs font-bold text-emerald-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  <span>DO (काय करावे):</span>
                </div>
                <ul className="space-y-2 text-xs text-slate-700">
                  {selected.dos.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-emerald-700 font-bold">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Mandatory DONTs */}
              <div className="bg-red-50/70 p-4 rounded-xl border border-red-200">
                <div className="text-xs font-bold text-red-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-red-700" />
                  <span>DO NOT (काय करू नये):</span>
                </div>
                <ul className="space-y-2 text-xs text-slate-700">
                  {selected.donts.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-red-700 font-bold">✕</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Guidance by Sadguru Medical B.Pharm Team</span>
              <span>In severe emergency, immediately call 108 Ambulance service</span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
