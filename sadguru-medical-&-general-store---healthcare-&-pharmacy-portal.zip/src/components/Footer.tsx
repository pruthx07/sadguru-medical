/**
 * ==============================================================================
 * PHARMACY FOOTER & REGULATORY COMPLIANCE DISCLOSURE
 * ==============================================================================
 *
 * [STUDENT PROJECT EXPLANATION]:
 * By Indian Drugs and Cosmetics Act (1940) and Maharashtra Food & Drug
 * Administration (FDA), licensed online healthcare portals must display
 * pharmacy license details, physical registered office, and drug warnings.
 */

import React from 'react';
import { ShieldCheck, MapPin, Phone, Mail, FileText, Heart } from 'lucide-react';
import { SADGURU_STORE_INFO } from '../data/storeInfo';
import { Language } from '../data/translations';

interface FooterProps {
  language: Language;
  onOpenPrescription: () => void;
  onOpenGenericSaver: () => void;
  onOpenDoseTracker: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  onOpenPrescription,
  onOpenGenericSaver,
  onOpenDoseTracker,
}) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-8 border-t border-slate-800 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          
          {/* Col 1: Brand & Credentials */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-base">
                <span className="font-display">स</span>
              </div>
              <span className="text-lg font-bold text-white tracking-tight font-display">
                Sadguru Medical
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Serving Kasba Tarle, Radhanagri taluka and rural Kolhapur with 100% genuine pharmaceutical care, prescription fulfillment, and home delivery.
            </p>
            <div className="text-[11px] font-mono text-emerald-400">
              FDA Lic: {SADGURU_STORE_INFO.licenseNumber}
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              GSTIN: {SADGURU_STORE_INFO.gstin}
            </div>
          </div>

          {/* Col 2: Quick Services */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Healthcare Services
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={onOpenPrescription}
                  className="hover:text-emerald-400 transition-colors text-slate-400 hover:underline"
                >
                  Upload Doctor's Prescription
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenGenericSaver}
                  className="hover:text-emerald-400 transition-colors text-slate-400 hover:underline"
                >
                  Jan Aushadhi Generic Price Saver
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenDoseTracker}
                  className="hover:text-emerald-400 transition-colors text-slate-400 hover:underline"
                >
                  Daily Pill & Dose Reminder
                </button>
              </li>
              <li>
                <a href="#store-info" className="hover:text-emerald-400 transition-colors text-slate-400 hover:underline">
                  Rural Village Delivery Checker
                </a>
              </li>
              <li>
                <a href="#health-guides" className="hover:text-emerald-400 transition-colors text-slate-400 hover:underline">
                  First Aid & Emergency Guides
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Physical Address */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Store Location
            </h4>
            <address className="not-italic text-xs text-slate-400 space-y-1 leading-relaxed">
              <div className="font-semibold text-slate-200">{SADGURU_STORE_INFO.name}</div>
              <div>At Post {SADGURU_STORE_INFO.address.village},</div>
              <div>Taluka: {SADGURU_STORE_INFO.address.taluka},</div>
              <div>Dist: {SADGURU_STORE_INFO.address.district}, Maharashtra - 416211</div>
              <div className="text-slate-500 pt-1">Landmark: {SADGURU_STORE_INFO.address.landmark}</div>
            </address>
          </div>

          {/* Col 4: Contact & Hours */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-3">
              Helpline & Pharmacist
            </h4>
            <div className="space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <a href={`tel:${SADGURU_STORE_INFO.phones[0]}`} className="hover:text-white font-mono">
                  {SADGURU_STORE_INFO.phones[0]}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">{SADGURU_STORE_INFO.email}</span>
              </div>
              <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                Owner & Reg. Pharmacist:<br />
                <span className="text-slate-200 font-semibold">{SADGURU_STORE_INFO.ownerName}</span>
                <span className="text-slate-400 block text-[10px]">{SADGURU_STORE_INFO.degrees}</span>
              </div>
              <div className="text-[11px] text-emerald-400">
                {SADGURU_STORE_INFO.hours}
              </div>
            </div>
          </div>

        </div>

        {/* Legal Disclaimer & Academic Project Attribution */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 text-center md:text-left">
          <div>
            © {new Date().getFullYear()} Sadguru Medical & General Store. Kasba Tarle, Radhanagri, Kolhapur 416211.
            <div className="text-[10px] text-slate-500 mt-0.5">
              Statutory Warning: Medicines should be taken under the supervision of a registered medical practitioner.
            </div>
          </div>

          <div className="flex items-center gap-2 text-slate-400">
            <span>Built for Academic Excellence & Rural Community Impact</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
