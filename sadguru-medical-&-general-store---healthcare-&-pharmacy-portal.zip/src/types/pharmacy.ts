/**
 * ==============================================================================
 * SADGURU MEDICAL & GENERAL STORE - DATA TYPES & INTERFACES
 * Location: At Post Kasba Tarle, Taluka Radhanagri, Dist. Kolhapur - 416211
 * ==============================================================================
 *
 * [FOR STUDENT PROJECT DEFENSE]:
 * TypeScript interfaces act as a "contract" or blueprint for the data in our
 * application. They ensure that every medicine, order, or prescription has the
 * exact fields required, preventing bugs and runtime errors.
 */

export type CategoryType = 
  | 'all'
  | 'prescription'
  | 'otc'
  | 'baby'
  | 'ayurvedic'
  | 'wellness'
  | 'devices'
  | 'firstaid';

export interface Medicine {
  id: string;
  name: string;
  marathiName: string;
  category: CategoryType;
  brand: string;
  manufacturer: string;
  composition: string; // The active chemical salt (e.g., "Paracetamol 650mg")
  dosageForm: 'Tablet' | 'Syrup' | 'Capsule' | 'Ointment' | 'Drops' | 'Device' | 'Powder';
  packSize: string; // e.g., "15 Tablets in 1 Strip"
  mrp: number; // Maximum Retail Price in INR (₹)
  sellingPrice: number; // Discounted Price in INR (₹)
  discountPercent: number;
  prescriptionRequired: boolean; // True if it falls under Schedule H/X drugs
  inStock: boolean;
  stockCount: number;
  description: string;
  uses: string[];
  sideEffects: string[];
  howToUse: string;
  safetyAdvice: {
    alcohol: string;
    pregnancy: string;
    driving: string;
  };
  // Generic alternative mapping for the "Generic Saver" feature
  genericEquivalent?: {
    saltName: string;
    genericPrice: number;
    savingsPercent: number;
    janAushadhiCode?: string;
  };
  imageBgColor?: string; // Fallback aesthetic background for product visuals
}

export interface CartItem {
  medicine: Medicine;
  quantity: number;
}

export interface PrescriptionOrder {
  id: string;
  patientName: string;
  patientAge: string;
  patientPhone: string;
  doctorName?: string;
  address: string;
  deliveryType: 'home_delivery' | 'store_pickup';
  prescriptionImageUri?: string;
  notes?: string;
  status: 'Pending Verification' | 'Pharmacist Review' | 'Packed' | 'Dispatched' | 'Delivered';
  createdAt: string;
}

export interface DosageReminder {
  id: string;
  medicineName: string;
  dosage: string; // e.g. "1 Tablet"
  timing: ('Morning' | 'Afternoon' | 'Night')[];
  mealRelation: 'Before Food' | 'After Food' | 'With Food';
  daysLeft: number;
  isTakenToday: boolean;
}

export interface StoreInfo {
  name: string;
  marathiName: string;
  tagline: string;
  ownerName: string;
  address: {
    village: string;
    taluka: string;
    district: string;
    state: string;
    pincode: string;
    landmark: string;
  };
  phones: string[];
  whatsapp: string;
  email: string;
  licenseNumber: string;
  gstin: string;
  pharmacistOnDuty: string;
  degrees: string;
  hours: string;
  emergency24x7: boolean;
}
