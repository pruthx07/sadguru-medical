/**
 * ==============================================================================
 * SADGURU MEDICAL & GENERAL STORE - MAIN REACT APPLICATION
 * Location: At Post Kasba Tarle, Taluka Radhanagri, Dist. Kolhapur - 416211
 * ==============================================================================
 *
 * [COMPREHENSIVE STUDENT GUIDE FOR FINAL YEAR PROJECT DEFENSE]:
 *
 * Hello! As a 3rd year student defending this project, here is how the architecture
 * works so you can explain every single part confidently:
 *
 * 1. STATE MANAGEMENT (React useState hooks):
 *    - `language`: Toggles between English ('en') and Marathi ('mr') for rural accessibility.
 *    - `cartItems`: Array storing medicines added to basket, with quantities.
 *    - `searchQuery`: Live text string typed in the search bar.
 *    - `selectedCategory`: The active category filter ('all', 'prescription', 'otc', etc.).
 *    - `genericOnlyFilter`: Boolean toggle showing only medicines with high-saving generic alternatives.
 *    - `activeModal`: Controls which modal is open ('prescription', 'genericSaver', 'detail', 'doseTracker', 'none').
 *
 * 2. PERFORMANCE OPTIMIZATION (React useMemo hook):
 *    - `filteredMedicines`: Computes filtered search results on the fly without lagging the browser.
 *      It searches across medicine brand names, Marathi names, and active chemical salts!
 *
 * 3. HEALTHCARE REGULATORY COMPLIANCE:
 *    - Implements India's Schedule H/X prescription rules (warnings displayed on restricted drugs).
 *    - Bio-equivalent Jan Aushadhi generic mapping to promote affordable rural healthcare.
 */

import React, { useState, useMemo } from 'react';
import { 
  Filter, 
  Sparkles, 
  Search, 
  Pill, 
  FileText, 
  CheckCircle2, 
  ArrowUpDown,
  SlidersHorizontal,
  X
} from 'lucide-react';

// Types & Data
import { Medicine, CartItem, CategoryType } from './types/pharmacy';
import { MEDICINES_DATABASE, CATEGORIES } from './data/medicinesData';
import { Language, TRANSLATIONS } from './data/translations';

// Modular UI Components
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { MedicineCard } from './components/MedicineCard';
import { PrescriptionUploadModal } from './components/PrescriptionUploadModal';
import { GenericSaverModal } from './components/GenericSaverModal';
import { MedicineDetailModal } from './components/MedicineDetailModal';
import { DoseTrackerModal } from './components/DoseTrackerModal';
import { CartDrawer } from './components/CartDrawer';
import { StoreLocationSection } from './components/StoreLocationSection';
import { HealthTipsSection } from './components/HealthTipsSection';
import { Footer } from './components/Footer';

export default function App() {
  // ----------------------------------------------------------------------------
  // APPLICATION STATE VARIABLES
  // ----------------------------------------------------------------------------
  const [language, setLanguage] = useState<Language>('en');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('all');
  const [genericOnlyFilter, setGenericOnlyFilter] = useState(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'discount'>('featured');
  const [activeSection, setActiveSection] = useState('hero');

  // Modal display states
  const [isPrescriptionModalOpen, setIsPrescriptionModalOpen] = useState(false);
  const [isGenericSaverOpen, setIsGenericSaverOpen] = useState(false);
  const [isDoseTrackerOpen, setIsDoseTrackerOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedMedicineForDetail, setSelectedMedicineForDetail] = useState<Medicine | null>(null);
  const [selectedMedicineForSaver, setSelectedMedicineForSaver] = useState<Medicine | null>(null);

  const t = TRANSLATIONS[language];

  // ----------------------------------------------------------------------------
  // CART OPERATIONS (Add, Update, Remove, Clear)
  // ----------------------------------------------------------------------------
  
  // Adds a medicine to basket, incrementing count if already present
  const handleAddToCart = (medicine: Medicine, quantity: number = 1) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.medicine.id === medicine.id);
      if (existing) {
        return prev.map(item =>
          item.medicine.id === medicine.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { medicine, quantity }];
    });
  };

  // Adjusts quantity (+1 or -1) from inside the Cart Drawer
  const handleUpdateQuantity = (medicineId: string, delta: number) => {
    setCartItems(prev =>
      prev
        .map(item => {
          if (item.medicine.id === medicineId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  // Removes a specific item from basket
  const handleRemoveItem = (medicineId: string) => {
    setCartItems(prev => prev.filter(item => item.medicine.id !== medicineId));
  };

  // Clears the entire cart after checkout completion
  const handleClearCart = () => {
    setCartItems([]);
  };

  // Total count of items currently in basket
  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // ----------------------------------------------------------------------------
  // INTELLIGENT FILTERING & SEARCH PIPELINE
  // ----------------------------------------------------------------------------
  const filteredMedicines = useMemo(() => {
    return MEDICINES_DATABASE.filter(med => {
      // 1. Category Filter
      if (selectedCategory !== 'all' && med.category !== selectedCategory) {
        return false;
      }

      // 2. Generic-Only Filter
      if (genericOnlyFilter && !med.genericEquivalent) {
        return false;
      }

      // 3. Search Query Filter (matches Name, Marathi Name, Composition Salt, or Brand)
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesName = med.name.toLowerCase().includes(query);
        const matchesMarathi = med.marathiName.toLowerCase().includes(query);
        const matchesComposition = med.composition.toLowerCase().includes(query);
        const matchesBrand = med.brand.toLowerCase().includes(query);
        const matchesUses = med.uses.some(u => u.toLowerCase().includes(query));

        if (!matchesName && !matchesMarathi && !matchesComposition && !matchesBrand && !matchesUses) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-low') return a.sellingPrice - b.sellingPrice;
      if (sortBy === 'price-high') return b.sellingPrice - a.sellingPrice;
      if (sortBy === 'discount') return b.discountPercent - a.discountPercent;
      return 0; // Default featured order
    });
  }, [selectedCategory, genericOnlyFilter, searchQuery, sortBy]);

  // Navigate directly to catalog section
  const handleNavigateToCatalog = () => {
    setActiveSection('catalog');
    const el = document.getElementById('catalog');
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* 1. TOP BAR (Strict 3-Zone Contract) */}
      <Navbar
        language={language}
        setLanguage={setLanguage}
        cartItemCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenPrescription={() => setIsPrescriptionModalOpen(true)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />

      <main className="flex-1">
        {/* 2. HERO SECTION & ACTION HUB */}
        <HeroSection
          language={language}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onOpenPrescription={() => setIsPrescriptionModalOpen(true)}
          onOpenGenericSaver={() => setIsGenericSaverOpen(true)}
          onNavigateToCatalog={handleNavigateToCatalog}
        />

        {/* 3. PRODUCT CATALOG & INTERACTIVE FILTER SECTION */}
        <section id="catalog" className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
          
          {/* Header Row: Title and Results Count */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 uppercase tracking-wider mb-1">
                <Pill className="w-4 h-4 text-emerald-700" />
                <span>Verified Dispensary Inventory</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
                {language === 'en' ? 'Authentic Medicines & Healthcare' : 'औषध भांडार व आरोग्य उत्पादने'}
              </h2>
              <div className="text-xs text-slate-500 mt-1 flex items-center gap-2">
                <span>Showing {filteredMedicines.length} verified products</span>
                <span aria-hidden="true">·</span>
                <span>Kasba Tarle Counter Stock</span>
              </div>
            </div>

            {/* Quick Upload Prescription Banner Button */}
            <button
              onClick={() => setIsPrescriptionModalOpen(true)}
              className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors self-start md:self-auto shadow-xs"
            >
              <FileText className="w-4 h-4 text-emerald-700" />
              <span>{language === 'en' ? 'Upload Doctor Prescription' : 'चिठ्ठी अपलोड करा'}</span>
            </button>
          </div>

          {/* Interactive Category Segmented Tabs (Functional Buttons) */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-6 no-scrollbar">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as CategoryType)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {language === 'mr' ? cat.marathiLabel : cat.label}
              </button>
            ))}
          </div>

          {/* Secondary Controls: Generic-Only Toggle & Sorting */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-200 text-xs">
            
            {/* Generic Filter Switch */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setGenericOnlyFilter(prev => !prev)}
                className={`px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-colors ${
                  genericOnlyFilter
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span className="font-semibold">
                  {language === 'en' ? 'Show Generic Price Savers Only' : 'फक्त जेनेरिक बचत पर्याय दाखवा'}
                </span>
              </button>

              {searchQuery && (
                <div className="flex items-center gap-1 text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
                  <span>Filtered by: "{searchQuery}"</span>
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="hover:text-slate-800 ml-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

            {/* Sort Selector */}
            <div className="flex items-center gap-2">
              <span className="text-slate-500 flex items-center gap-1">
                <ArrowUpDown className="w-3.5 h-3.5" />
                <span>Sort By:</span>
              </span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-emerald-600"
              >
                <option value="featured">Featured Inventory</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="discount">Highest Discount %</option>
              </select>
            </div>

          </div>

          {/* Product Grid (3-4 Columns on desktop with generous whitespace) */}
          {filteredMedicines.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {filteredMedicines.map((medicine) => {
                const isItemInCart = cartItems.some(i => i.medicine.id === medicine.id);
                return (
                  <MedicineCard
                    key={medicine.id}
                    medicine={medicine}
                    language={language}
                    onAddToCart={(med) => handleAddToCart(med, 1)}
                    onSelectMedicine={(med) => setSelectedMedicineForDetail(med)}
                    onCompareGeneric={(med) => {
                      setSelectedMedicineForSaver(med);
                      setIsGenericSaverOpen(true);
                    }}
                    isItemInCart={isItemInCart}
                  />
                );
              })}
            </div>
          ) : (
            /* Empty State */
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center max-w-lg mx-auto my-8">
              <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
                <Search className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-slate-800">
                No medicines found matching your query
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Try searching by chemical salt (e.g., 'Paracetamol') or upload your doctor's slip directly for our pharmacist to check warehouse stock.
              </p>
              <div className="mt-5 flex justify-center gap-3">
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                    setGenericOnlyFilter(false);
                  }}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Reset All Filters
                </button>
                <button
                  onClick={() => setIsPrescriptionModalOpen(true)}
                  className="px-4 py-2 bg-emerald-700 text-white rounded-lg text-xs font-semibold hover:bg-emerald-800"
                >
                  Upload Prescription
                </button>
              </div>
            </div>
          )}

        </section>

        {/* 4. HEALTH ADVISORY & FIRST AID GUIDES */}
        <HealthTipsSection language={language} />

        {/* 5. PHYSICAL STORE CREDENTIALS & RURAL DELIVERY CHECKER */}
        <StoreLocationSection language={language} />

      </main>

      {/* 6. FOOTER */}
      <Footer
        language={language}
        onOpenPrescription={() => setIsPrescriptionModalOpen(true)}
        onOpenGenericSaver={() => setIsGenericSaverOpen(true)}
        onOpenDoseTracker={() => setIsDoseTrackerOpen(true)}
      />

      {/* ------------------------------------------------------------------------ */}
      {/* MODALS & SLIDE-OVER PANELS */}
      {/* ------------------------------------------------------------------------ */}

      {/* Prescription Upload Modal */}
      <PrescriptionUploadModal
        isOpen={isPrescriptionModalOpen}
        onClose={() => setIsPrescriptionModalOpen(false)}
        language={language}
      />

      {/* Generic Medicine Price Saver Modal */}
      <GenericSaverModal
        isOpen={isGenericSaverOpen}
        onClose={() => setIsGenericSaverOpen(false)}
        medicines={MEDICINES_DATABASE}
        selectedMedicine={selectedMedicineForSaver}
        onAddToCart={(med) => handleAddToCart(med, 1)}
        language={language}
      />

      {/* Medicine Detailed Monograph View Modal */}
      <MedicineDetailModal
        medicine={selectedMedicineForDetail}
        isOpen={!!selectedMedicineForDetail}
        onClose={() => setSelectedMedicineForDetail(null)}
        onAddToCartWithQty={(med, qty) => handleAddToCart(med, qty)}
        onOpenGenericSaver={(med) => {
          setSelectedMedicineForSaver(med);
          setIsGenericSaverOpen(true);
        }}
        language={language}
      />

      {/* Daily Pill & Dosage Reminder Modal */}
      <DoseTrackerModal
        isOpen={isDoseTrackerOpen}
        onClose={() => setIsDoseTrackerOpen(false)}
        language={language}
      />

      {/* Shopping Cart Drawer & Checkout Invoice */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        language={language}
      />

    </div>
  );
}
